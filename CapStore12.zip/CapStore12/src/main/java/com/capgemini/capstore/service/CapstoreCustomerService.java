package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Order;

public interface CapstoreCustomerService {
	public boolean generateReturnRequest(Order order);
}
