package com.capgemini.capstore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.service.CapstoreAdminService;
import com.capgemini.capstore.service.CapstoreCustomerServiceImpl;
import com.capgemini.capstore.service.CapstoreMerchantService;

@RestController
public class CapStoreController {
	
	@Autowired
	CapstoreCustomerServiceImpl capstoreCustomerService;
	
	@Autowired
	CapstoreMerchantService capstoreMerchantService;
	
	@Autowired
	CapstoreAdminService capstoreAdminService;
	
	
	
	@RequestMapping(value="/getStudent", method = RequestMethod.GET)
	public String getStudent()
	{
		
		return "new test";
		
	}
	
	
	
	@RequestMapping(value = "/generateReturnRequest", method = RequestMethod.POST)
	public boolean generateReturnRequest(@RequestBody Order order) {
		return capstoreCustomerService.generateReturnRequest(order);
	}
	
//	@RequestMapping(value = "/generateReturnRequest", method = RequestMethod.POST)
//	public boolean verifyReturnRequest(ReturnRequest returnRequest, boolean status)
//	{
//		return capstoreCustomerService.generateReturnRequest(order);
//	}
	
	
	
	
}
