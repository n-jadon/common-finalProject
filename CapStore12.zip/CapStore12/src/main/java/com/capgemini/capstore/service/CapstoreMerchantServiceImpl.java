package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.ReturnRequest;
import com.capgemini.capstore.beans.ReturnStatus;
import com.capgemini.capstore.dao.CapStoreReturnRequest;

@Service
public class CapstoreMerchantServiceImpl implements CapstoreMerchantService {
	
	@Autowired
	CapStoreReturnRequest capstoreReturnRequest;
	
	@Override
	public double refundMoney(ReturnRequest returnRequest) {
		if(returnRequest.getReturnStatus()==ReturnStatus.Approved)
		{
			return returnRequest.getRefundAmount();
		}
		return(0);
	}
	
}
