package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.ReturnRequest;

public interface CapstoreMerchantService {
	public double refundMoney(ReturnRequest returnRequest); 
}
