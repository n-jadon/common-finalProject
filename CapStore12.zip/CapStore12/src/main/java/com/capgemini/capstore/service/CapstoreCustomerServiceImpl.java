package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.DeliveryStatus;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.ReturnRequest;
import com.capgemini.capstore.beans.ReturnStatus;
import com.capgemini.capstore.dao.CapStoreReturnRequest;

@Service
public class CapstoreCustomerServiceImpl implements CapstoreCustomerService {
	
	@Autowired
	CapStoreReturnRequest capstoreReturnRequest;
	
	@Override
	public boolean generateReturnRequest(Order order) {
		if(order.getDeliveryStatus()==DeliveryStatus.Delivered)
		{
			ReturnRequest returnRequest = new ReturnRequest();
			returnRequest.setCustomer(order.getCustomer());
			returnRequest.setMerchant(order.getMerchant());
			returnRequest.setOrder(order);
			returnRequest.setProduct(order.getProduct());
			returnRequest.setRefundAmount(order.getTotalProductPrice());
			returnRequest.setReturnStatus(ReturnStatus.Applied);
			capstoreReturnRequest.save(returnRequest);
			return true;
		}
		else
		{
			return false;
		}
	}

}
