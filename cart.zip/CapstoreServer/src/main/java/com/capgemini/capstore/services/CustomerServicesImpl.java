package com.capgemini.capstore.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Wishlist;
import com.capgemini.capstore.exceptions.InvalidInputException;
import com.capgemini.capstore.exceptions.ProductUnavailableException;
import com.capgemini.capstore.repo.CartRepo;
import com.capgemini.capstore.repo.CustomerRepo;
import com.capgemini.capstore.repo.OrdersRepo;
import com.capgemini.capstore.repo.ProductRepo;
import com.capgemini.capstore.repo.WishlistRepo;


@Service(value = "customerServices")
public class CustomerServicesImpl implements CustomerServices {

	Customer customer;
	Product product;

	@Autowired
	private CustomerRepo customerRepo;

	@Autowired
	private CartRepo cartRepo;

	@Autowired
	private WishlistRepo wishlistRepo;

	@Autowired
	private ProductRepo productRepo;

	@Autowired
	private OrdersRepo ordersRepo;

	/*
	 * @Override public double applyDiscount(int productId) { product =
	 * productRepo.getOne(productId);
	 * 
	 * String discount = product.getDiscountOffered()();
	 * 
	 * double price = product.getProductPrice(); double finalPrice = price; if
	 * (discountIsValid(discount)) { double percentDiscount =
	 * discount.getPercentDiscount(); finalPrice = price - ((price *
	 * percentDiscount) / 100); product.setProductPrice(finalPrice); } return
	 * finalPrice; }
	 * 
	 * public boolean discountIsValid(String discount) {
	 * 
	 * Date date2 = discount.getEndDateOfDiscount(); Date date1 =
	 * discount.getStartDateOfDiscount(); if (date1.before(new Date()) &&
	 * date2.after(new Date())) {
	 * 
	 * return true; } return false; }
	 * 
	 * @Override
	 * 
	 * public double applyCoupon(int cartId) { Cart cart = cartRepo.getOne(cartId);
	 * Coupon coupon = cart.getCoupon(); double cartAmount = cart.getTotalAmount();
	 * double finalPrice = cartAmount; if (couponIsValid(coupon)) { double
	 * couponDiscount = coupon.getCouponDiscountValue(); finalPrice = cartAmount -
	 * ((cartAmount * couponDiscount) / 100); cart.setTotalAmount(finalPrice); }
	 * return finalPrice; }
	 */

	/*
	 * public boolean couponIsValid(Coupon coupon) { Date date2 =
	 * coupon.getCouponEndDate(); Date date1 = coupon.getCouponStartDate(); if
	 * (date1.before(new Date()) && date2.after(new Date())) {
	 * 
	 * return true; } return false; }
	 */

	@Override
	public List<Cart> getAllProductsFromCart(String customerId) throws InvalidInputException {
		List<Cart> cartList;

		customer = customerRepo.getOne(customerId);
	cartList = cartRepo.findCartsByCustomer(customer);
		return cartList;
	}

	@Override
	public boolean addProductToWishlist(String customerId, int productId) throws InvalidInputException {
		product = productRepo.getOne(productId);
		customer = customerRepo.getOne(customerId);
		Wishlist wishlist = wishlistRepo.findByCustomerAndProduct(customer, product);
		if (wishlist == null) {
			wishlist = new Wishlist();
			wishlist.setCustomer(customer);
			wishlist.setProduct(product);
			wishlistRepo.save(wishlist);

		} else {
			wishlistRepo.save(wishlist);

		}
		return true;
	}

	@Override
	public boolean removeProductFromWishlist(String phoneNumber, int productId) throws InvalidInputException {
		product = productRepo.getOne(productId);
		customer = customerRepo.getOne(phoneNumber);
		Wishlist wishlist = wishlistRepo.findByCustomerAndProduct(customer, product);
		if(wishlist!=null)
		wishlist=wishlistRepo.DeleteWhereCustomerAndProduct(customer, product);
		return true;
	}

	@Override
	public List<Wishlist> getAllWishlist(String customerId) throws InvalidInputException {
		List<Wishlist> wishlist = new ArrayList<Wishlist>();
		try {
			customer = customerRepo.getOne(customerId);
			wishlist = wishlistRepo.findWishlistsByCustomer(customer);
		} catch (Exception e) {
			e.getMessage();
		}
		return wishlist;
	}

	@Override
	public Cart addProductToNewCart(String phoneNumbercustomerId, int productId, int quantity)
			throws ProductUnavailableException {
		product = productRepo.getOne(productId);
		String error = "This quantity of the product is not available";
		if (product.getProductQuantityAvailable() > quantity) {
			Cart cart = new Cart();
			List<Product> products = new ArrayList<Product>();
			product.setCartQuantity(quantity);
			products.add(product);
			double productPrice = product.getProductPrice();
			double amount = productPrice * quantity;
			cart.setTotalAmount(amount);
			cart.setProducts(products);
			cart.setCustomer(customerRepo.getOne(phoneNumber));
			return cartRepo.save(cart);
		} else
			throw new ProductUnavailableException(error);
	}

	@Override
	public Cart updateCart(String phoneNumber, int productId, int quantity) throws ProductUnavailableException {
		customer = customerRepo.getOne(phoneNumber);

		Cart cart = cartRepo.findByCustomer(customer);
		String error = "This quantity of the product is not Available";

		List<Product> products = cart.getProducts();

		int productIndex = products.indexOf(new Product(productId));

		product = products.get(productIndex);
		if (product.getProductQuantityAvailable() > quantity) {
			if (product.getCartQuantity() > quantity) {
				double productPrice = product.getProductPrice();
				double productAmount = productPrice * (product.getCartQuantity() - quantity);
				double amount = cart.getTotalAmount();
				double totalAmount = amount - productAmount;
				product.setCartQuantity(quantity);
				cart.setTotalAmount(totalAmount);
			} else if (product.getCartQuantity() < quantity) {
				double productPrice = product.getProductPrice();
				double productAmount = productPrice * (quantity - product.getCartQuantity());
				double amount = cart.getTotalAmount();
				double totalAmount = amount + productAmount;
				cart.setTotalAmount(totalAmount);
			}
			products.set(productIndex, product);
			cart.setProducts(products);
			return cartRepo.save(cart);
		} else
			throw new ProductUnavailableException(error);
	}

	@Override
	public Cart removeProductFromCart(String phoneNumber, int productId) {
		customer = customerRepo.getOne(phoneNumber);
		Cart cart = cartRepo.findByCustomer(customer);
		List<Product> products = cart.getProducts();
		int productIndex = products.indexOf(new Product(productId));
		
		products.remove(productIndex);
		cart.setProducts(products);
		return cartRepo.save(cart);
		
	}

}
