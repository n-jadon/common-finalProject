package com.capgemini.capstore.repo;
import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.beans.Order;

public interface OrdersRepo extends JpaRepository<Order, Integer>{

}
