package com.capgemini.capstore.repo;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Wishlist;

public interface WishlistRepo extends JpaRepository<Wishlist, Integer>,CrudRepository<Wishlist, Integer>{

	public Wishlist findByCustomerAndProduct(Customer customer,Product product);
	public Wishlist DeleteWhereCustomerAndProduct(Customer customer,Product product);
	public List<Wishlist> findWishlistsByCustomer(Customer customer);
	
}
