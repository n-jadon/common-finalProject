package com.capgemini.capstore.services;

import java.util.List;

import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Category;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Wishlist;
import com.capgemini.capstore.exceptions.CustomerNotFoundException;
import com.capgemini.capstore.exceptions.InvalidInputException;
import com.capgemini.capstore.exceptions.ProductUnavailableException;

public interface CustomerServices {

	public boolean addProductToWishlist(String phoneNumber,int productId) throws InvalidInputException;

	public boolean removeProductFromWishlist(String phoneNumber,int productId) throws InvalidInputException;

	public List<Wishlist> getAllWishlist(String phoneNumber) throws InvalidInputException;

	public List<Cart> getAllProductsFromCart(String phoneNumber) throws InvalidInputException;

	Cart addProductToNewCart(String phoneNumber,int productId, int quantity) throws ProductUnavailableException;

	Cart updateCart(String phoneNumber,int productId, int quantity) throws ProductUnavailableException;

	Cart removeProductFromCart(String phoneNumber,int productId);//once removed from cart, update stock & quantity in product

	/*
	 * double applyDiscount(int productId);
	 * 
	 * double applyCoupon(int cartId);
	 */
}
