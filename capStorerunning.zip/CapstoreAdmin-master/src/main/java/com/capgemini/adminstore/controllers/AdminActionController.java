package com.capgemini.adminstore.controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminActionController {
	
}
