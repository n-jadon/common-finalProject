package com.capgemini.merchantstore.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MerchantstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(MerchantstoreApplication.class, args);
	}
}
