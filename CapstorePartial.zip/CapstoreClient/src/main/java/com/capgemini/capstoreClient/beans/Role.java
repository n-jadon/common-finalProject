package com.capgemini.capstoreClient.beans;

public enum Role {
	Customer,Admin,Merchant
}
