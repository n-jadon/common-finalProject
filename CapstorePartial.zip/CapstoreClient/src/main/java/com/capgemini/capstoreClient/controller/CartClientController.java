package com.capgemini.capstoreClient.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.capgemini.capstoreClient.beans.CartDTO;


@Controller
public class CartClientController {
	
	private static final String MODIFY_QUANTITY = "modifyQuantity";
	private static final String REMOVE = "remove";
	
	@RequestMapping("cart")
	public String Cart(ModelMap map,@RequestParam(value = "action", required = false) String action,
			@RequestParam(value = "id", required = false) String itemId){
		int customerId=1;
		
		RestTemplate restTemplate = new RestTemplate();
		
		/*if(action.equals(MODIFY_QUANTITY))
		{
//			Response response = restTemplate.getForObject("http://localhost:8088/api/cart/modify/"+itemId,Response.class);
		}
		else if(action.equals(REMOVE))
		{
//			Response response = restTemplate.getForObject("http://localhost:8088/api/cart/remove/"+itemId,Response.class);
		}*/
		 System.out.println("ABCDEFGHIJKL");
		ArrayList<CartDTO> cartlist = restTemplate.getForObject("http://localhost:8088/api/cart/"+customerId,ArrayList.class);
		System.out.println(cartlist);
		System.out.println(cartlist.size());
		/*map.addAttribute("cart",cartlist);
		for(CartDTO c:cartlist) {
			System.out.println(c.getCustomer().getCustomerName());
		System.out.println(c.getProduct().getProductName());
		}*/
		System.out.println("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
			return "cart";
		}
}
