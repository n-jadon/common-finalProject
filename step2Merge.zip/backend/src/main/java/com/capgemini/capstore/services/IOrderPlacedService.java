package com.capgemini.capstore.services;

import java.util.List;

import com.capgemini.capstore.dto.CartDTO;



public interface IOrderPlacedService {

	public List<CartDTO> getOrderPlacedProduct();
}
