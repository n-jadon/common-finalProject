package com.paypal.paymentPaypal.bean;

public enum Role {
	Customer,Admin,Merchant
}
