package com.paypal.paymentPaypal;

import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

//import com.capgemini.capstoreClient.beans.Customer;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.paypal.paymentPaypal.bean.Customer;

@Controller
public class CustomerController {
	
	@RequestMapping("viewCustomer")
	public String viewCustomer(ModelMap map) {
		int customerId=1;
		RestTemplate restTemplate = new RestTemplate();
		
		Customer customer=restTemplate.getForObject("http://localhost:8088/api/viewCustomer/"+customerId, Customer.class);
		
		map.put("customer",customer);
		System.out.println(customer.getCustomerName());
		System.out.println(customer.getCustomerMobileNumber());
		return "Customerprofile";
	}
	@RequestMapping("editCustomer")
	public String editCustomer(ModelMap map) {
		int customerId=1;
		RestTemplate restTemplate = new RestTemplate();
		
		Customer customer=restTemplate.getForObject("http://localhost:8088/api/viewCustomer/"+customerId, Customer.class);
		
		map.put("customer",customer);
		return "CustomerEditProfile";
	}
	@RequestMapping("updateCustomer")
	public String updateCustomer(@ModelAttribute("customer") Customer customer,ModelMap map) {
		int customerId=1;
		RestTemplate restTemplate = new RestTemplate();
		customer.setCustomerId(customerId);
		
		Customer customer1=restTemplate.postForObject("http://localhost:8088/api/updateCustomer", customer, Customer.class);
		map.put("customer",customer1);
		return "Customerprofile";
	}
	@RequestMapping("indexCustomer")
	public String indexCustomer(ModelMap map) {
		/*int customerId=1;
		RestTemplate restTemplate = new RestTemplate();
		
		Customer customer=restTemplate.getForObject("http://localhost:8088/api/viewCustomer/"+customerId, Customer.class);
		
		map.put("customer",customer);*/
		return "CustomerIndex";
	}
}