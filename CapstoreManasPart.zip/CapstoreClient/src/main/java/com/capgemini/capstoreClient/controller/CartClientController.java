package com.capgemini.capstoreClient.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.capgemini.capstoreClient.beans.CartDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;


@Controller
public class CartClientController {
	
	private static final String MODIFY_QUANTITY = "modifyQuantity";
	private static final String REMOVE = "remove";
	private static final String VIEW_CART = "view_cart";
	
	@RequestMapping("cart")
	public String Cart(ModelMap map,@RequestParam(value = "action") String action,
			@RequestParam(value = "id", required = false) String itemId) throws JsonParseException, JsonMappingException, IOException{
		int customerId=1;
		
		RestTemplate restTemplate = new RestTemplate();
		
		/*if(action.equals(MODIFY_QUANTITY))
		{
//			Response response = restTemplate.getForObject("http://localhost:8088/api/cart/modify/"+itemId,Response.class);
		}
		else */if(action.equals(REMOVE))
		{
			restTemplate.getForObject("http://localhost:8088/api/removeFromCart/"+itemId,void.class);
		}
		 System.out.println("ABCDEFGHIJKL");
		ArrayList<CartDTO> cartlist = restTemplate.getForObject("http://localhost:8088/api/cart/"+customerId,ArrayList.class);
		
		ObjectMapper mapper=new ObjectMapper();
		mapper.addMixIn(Object.class, IgnoreHibernatePropertiesInJackson.class);
		String jsonArray=mapper.writeValueAsString(cartlist);
		
		CollectionType javaType=mapper.getTypeFactory().constructCollectionType(ArrayList.class, CartDTO.class);
		ArrayList<CartDTO> cartItems=mapper.readValue(jsonArray, javaType);
		
		System.out.println(cartItems);
		System.out.println(cartItems.size());
		map.put("cart",cartItems);
		for(CartDTO c:cartItems) {
			System.out.println(c.getProduct().getProductName());
		}
		System.out.println("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
			return "cart";
		}
}

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
abstract class IgnoreHibernatePropertiesInJackson{ }
