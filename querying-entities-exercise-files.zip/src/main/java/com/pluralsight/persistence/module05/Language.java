package com.pluralsight.persistence.module05;

/**
 * @author Antonio Goncalves
 *         http://www.antoniogoncalves.org
 *         --
 */
public enum Language {
  ENGLISH, FRENCH, SPANISH, PORTUGUESE, RUSSIAN, CHINESE, INDIAN, GERMAN, JAPANESE
}