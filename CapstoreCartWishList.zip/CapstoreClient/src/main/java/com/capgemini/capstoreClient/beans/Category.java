package com.capgemini.capstoreClient.beans;

public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics,Sports
}
