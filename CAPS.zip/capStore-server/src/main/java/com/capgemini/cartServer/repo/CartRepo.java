package com.capgemini.cartServer.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.cartServer.dto.CartDTO;

@Repository	
public class CartRepo implements ICartRepo{
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public boolean addToCart(CartDTO cart) {
		try {
			entityManager.persist(cart);											//Saving the product to the database
		}
		catch (RuntimeException e) {
			throw e;
		}
		entityManager.close();
		entityManager.flush();
		return true;
	}

	@Override
	public void updateCart(String cartId) {
		CartDTO cart=new CartDTO();
		entityManager.merge(cart);												//updatig product using primary key as id
		entityManager.flush();
	}

	@Override
	public List<CartDTO> getCartList() {
		Query query = entityManager.createQuery("select items from Cart items");	//Creating query for getting all values from database
		try {
		List<CartDTO> ls=(List<CartDTO>)query.getResultList();					//getting list of results
		entityManager.close();
		entityManager.flush();
		return ls;
		}
		catch (RuntimeException e) {
			throw e;
		}
	}

	@Override
	public boolean removeCart(String cartId) {
		CartDTO cart= entityManager.find(CartDTO.class, cartId);
		entityManager.remove(cart);												//deleting product using product id
		entityManager.flush();
		return true;
	}

}
