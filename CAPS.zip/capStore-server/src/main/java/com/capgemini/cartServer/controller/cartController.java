package com.capgemini.cartServer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.cartServer.dto.CartDTO;
import com.capgemini.cartServer.service.CartService;

@RestController
@RequestMapping("/api/cart")
public class cartController {
	
	@Autowired
	CartService service;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<CartDTO> view(){								//View all the products from the database
//		return service.getCartList();
		return null;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public void create(/*@RequestBody*/ CartDTO cart)			//get product JSON object using POST request
	{
		service.addToCart(cart);
	}
	
	@RequestMapping(method=RequestMethod.GET,value="modify/{id}")		//Send product JSON object using PUT request and update the existing object
	public void update(@PathVariable(value="id") String id) {
		service.updateCart(id);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="remove/{id}")	//Delete product from database using product id, get via DELETE request
	public void delete(@PathVariable(value="id") String id) {
		service.removeCart(id);
	}
}
	
