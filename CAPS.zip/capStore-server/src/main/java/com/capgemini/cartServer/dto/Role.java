package com.capgemini.cartServer.dto;
public enum Role {
	Customer,Admin,Merchant
}
