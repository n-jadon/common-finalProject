package com.capgemini.cartServer.service;

import java.util.List;

import com.capgemini.cartServer.dto.CartDTO;

public interface ICartService {
	public boolean addToCart(CartDTO cart);
	public void updateCart(String cartId);
	public List<CartDTO> getCartList();
	public boolean removeCart(String cartId);
}
