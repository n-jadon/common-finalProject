package com.capgemini.cartServer.service;

import java.util.List;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cartServer.dto.CartDTO;
import com.capgemini.cartServer.repo.CartRepo;

@Service("service")
@Transactional
public class CartService implements ICartService{
	
	@Autowired
	CartRepo cartRef;

	@Override
	public boolean addToCart(CartDTO cart) {
		return cartRef.addToCart(cart);
	}

	@Override
	public void updateCart(String cartId) {
		cartRef.updateCart(cartId);
	}

	@Override
	public List<CartDTO> getCartList() {
		return cartRef.getCartList();
	}

	@Override
	public boolean removeCart(String cartId) {
		return cartRef.removeCart(cartId);
	}

}
