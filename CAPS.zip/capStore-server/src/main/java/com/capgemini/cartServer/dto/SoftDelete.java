package com.capgemini.cartServer.dto;
public enum SoftDelete {
	Activated, Deactivated
}
