package com.capgemini.cartServer.repo;

import java.util.List;

import com.capgemini.cartServer.dto.CartDTO;

public interface ICartRepo {
	public boolean addToCart(CartDTO cart);
	public void updateCart(String cartId);
	public List<CartDTO> getCartList();
	public boolean removeCart(String cartId);
}
