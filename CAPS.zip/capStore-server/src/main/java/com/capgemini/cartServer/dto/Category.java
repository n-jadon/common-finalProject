package com.capgemini.cartServer.dto;
public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics,Sports
}
