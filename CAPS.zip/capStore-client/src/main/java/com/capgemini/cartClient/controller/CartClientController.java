package com.capgemini.cartClient.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.capgemini.cartClient.dto.Response;


@Controller
public class CartClientController {
	
	private static final String MODIFY_QUANTITY = "modifyQuantity";
	private static final String REMOVE = "remove";
	
	@RequestMapping("/cart")
	public String Cart(ModelMap map,@RequestParam(value = "action", required = false) String action,
			@RequestParam(value = "id", required = false) String itemId){
		int customerId;
		
		RestTemplate restTemplate = new RestTemplate();
		if(action.equals(MODIFY_QUANTITY))
		{
			Response response = restTemplate.getForObject("http://localhost:8088/api/cart/modify/"+itemId,Response.class);
		}
		else if(action.equals(REMOVE))
		{
			Response response = restTemplate.getForObject("http://localhost:8088/api/cart/remove/"+itemId,Response.class);
		}
		 
		Response cart = restTemplate.getForObject("http://localhost:8088/api/cart",Response.class);
		map.addAttribute("cart",cart);
			return "cart";
		}
}
