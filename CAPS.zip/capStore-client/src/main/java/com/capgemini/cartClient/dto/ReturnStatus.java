package com.capgemini.cartClient.dto;

public enum ReturnStatus {
	Applied, Approved, Rejected
}
