package com.capgemini.cartClient.dto;

public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics
}
