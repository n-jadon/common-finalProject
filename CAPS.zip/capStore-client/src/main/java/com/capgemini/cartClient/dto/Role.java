package com.capgemini.cartClient.dto;

public enum Role {
	Customer,Admin,Merchant
}
