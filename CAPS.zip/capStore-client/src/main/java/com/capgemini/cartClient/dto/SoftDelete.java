package com.capgemini.cartClient.dto;

public enum SoftDelete {
	Activated, Deactivated
}
