package com.capgemini.cartClient.dto;

import java.util.Arrays;

public class RestResponse {
	private String[] messages;
	private Cart cart;

	public RestResponse() {
	}

	public String[] getMessages() {
		return messages;
	}

	public void setMessages(String[] messages) {
		this.messages = messages;
	}


	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	@Override
	public String toString() {
		return "RestResponse [messages=" + Arrays.toString(messages) + ", result=" + cart + "]";
	}
}
