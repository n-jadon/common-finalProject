package com.capgemini.cartClient.dto;

public enum DeliveryStatus {
	Ordered, Shipped, OutForDelivery, Delivered
}
